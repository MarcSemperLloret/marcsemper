# Mi proyecto de Desarrollo Web en Entorno Servidor

## Propuesta
Completa aquí usuario, finalidad, entidades, reglas y operación de varios cambios de tu proyecto.

## Requisitos
JDK 21 e Internet para la primera descarga de Maven y sus dependencias.
Base del curso: Spring Boot 3.5.16 con Spring Web y Maven Wrapper.
Estructura generada con Spring Initializr y ajustada a la serie 3.5 del módulo.
Los scripts del wrapper conservan sus avisos de licencia originales.

## Arranque
Desde la carpeta de pom.xml:
- Windows / PowerShell: `.\mvnw.cmd spring-boot:run`
- Linux / macOS: `./mvnw spring-boot:run`
Detener: Ctrl+C en la terminal de ejecución.

La plantilla no incluye rutas propias: se escriben en la sesión 1.
Antes de crearlas, http://localhost:8080/ devuelve 404 con el servidor encendido.

## Rutas y comprobaciones
Describe las rutas que has construido y comprueba sus respuestas. Debes poder explicar qué funciona y qué queda pendiente.

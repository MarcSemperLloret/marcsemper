# Mi proyecto de Desarrollo Web en Entorno Servidor

## Propuesta
Completa aquí usuario, finalidad, entidades, reglas y operación de varios cambios de tu proyecto.

## Requisitos
JDK 21 e Internet para la primera descarga de Maven y sus dependencias.
Base del curso: Spring Boot 3.5.16 con Spring Web y Maven Wrapper.
Estructura generada con Spring Initializr y ajustada a la serie 3.5 del módulo.
Los scripts del wrapper conservan sus avisos de licencia originales.

## Arranque
Desde la carpeta de pom.xml:
- Windows / PowerShell: `.\mvnw.cmd spring-boot:run`
- Linux / macOS: `./mvnw spring-boot:run`
Detener: Ctrl+C en la terminal de ejecución.

La plantilla no incluye rutas propias: se escriben en la sesión 1.
Antes de crearlas, http://localhost:8080/ devuelve 404 con el servidor encendido.

## Rutas y comprobaciones
Completa este apartado durante la sesión y redacta su registro en Word, LibreOffice o un documento en línea. Expórtalo como docs/sesiones/sesion-01.pdf antes del commit y conserva el original editable para actualizarlo.

"""Laboratorio con cuatro fallos deliberados. Solo datos ficticios y localhost.
La cabecera X-Demo-User simula una identidad ya validada; no implementa login.
"""
import json
import sqlite3
from http.server import BaseHTTPRequestHandler, HTTPServer
from urllib.parse import urlparse, parse_qs

ORDERS = {1: {"id": 1, "owner": "ana", "item": "Teclado"},
          2: {"id": 2, "owner": "bruno", "item": "Ratón"}}
CONFIG = {"site": "Tienda de laboratorio", "demo_secret": "FICTICIO-NO-ES-UNA-CREDENCIAL"}

def get_order(user, order_id):
    if not user:
        return 401, {"error": "Identidad necesaria"}
    order = ORDERS.get(order_id)
    if order is None:
        return 404, {"error": "No existe"}
    # Reto 1: falta una regla de autorización sobre este pedido.
    return 200, dict(order)

def search_products(query):
    # Base efímera sin datos personales; se crea para cada demostración.
    with sqlite3.connect(":memory:") as db:
        db.execute("CREATE TABLE products (name TEXT)")
        db.executemany("INSERT INTO products VALUES (?)", [("Teclado",), ("Ratón",)])
        # Reto 2: el dato se mezcla con SQL.
        sql = "SELECT name FROM products WHERE name = '" + query + "'"
        rows = db.execute(sql).fetchall()
    return 200, {"products": [r[0] for r in rows]}

def public_config():
    # Reto 3: esta respuesta debe incluir solo información pública.
    return 200, dict(CONFIG)

def error_response(exc):
    # Reto 4: el detalle técnico no pertenece a una respuesta pública.
    return 500, {"error": str(exc), "type": type(exc).__name__}

class Handler(BaseHTTPRequestHandler):
    def do_GET(self):
        parsed = urlparse(self.path)
        try:
            if parsed.path == "/":
                status, body = 200, {"lab": "Lee guia-seguridad.pdf; solo datos ficticios", "routes": ["/orders/1", "/products?q=Teclado", "/config", "/demo-error"]}
            elif parsed.path.startswith("/orders/"):
                user = self.headers.get("X-Demo-User")
                if user not in ("ana", "bruno", "admin"): user = None
                status, body = get_order(user, int(parsed.path.rsplit("/", 1)[1]))
            elif parsed.path == "/products":
                status, body = search_products(parse_qs(parsed.query).get("q", [""])[0])
            elif parsed.path == "/config":
                status, body = public_config()
            elif parsed.path == "/demo-error":
                raise RuntimeError("Ruta interna ficticia /datos/pedidos.sqlite")
            else:
                status, body = 404, {"error": "No existe"}
        except Exception as exc:
            status, body = error_response(exc)
        payload = json.dumps(body, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(payload)))
        self.end_headers()
        self.wfile.write(payload)

if __name__ == "__main__":
    print("Laboratorio local: http://127.0.0.1:8090 · Ctrl+C para parar", flush=True)
    HTTPServer(("127.0.0.1", 8090), Handler).serve_forever()

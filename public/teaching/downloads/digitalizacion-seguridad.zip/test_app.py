import unittest
import app

class ReglasDelLaboratorio(unittest.TestCase):
    def test_pedido_propio_y_admin(self):
        self.assertEqual(app.get_order("ana", 1)[0], 200)
        self.assertEqual(app.get_order("admin", 2)[0], 200)

    def test_sin_identidad(self):
        self.assertEqual(app.get_order(None, 1)[0], 401)

    def test_pedido_ajeno_rechazado(self):
        self.assertEqual(app.get_order("ana", 2)[0], 403)

    def test_busqueda_normal(self):
        self.assertEqual(app.search_products("Teclado"), (200, {"products": ["Teclado"]}))

    def test_entrada_sql_es_un_dato(self):
        self.assertEqual(app.search_products("' OR 1=1 --"), (200, {"products": []}))

    def test_config_solo_publica(self):
        self.assertEqual(app.public_config(), (200, {"site": "Tienda de laboratorio"}))

    def test_error_publico_sin_detalles(self):
        self.assertEqual(app.error_response(RuntimeError("dato-interno-ficticio")),
                         (500, {"error": "Error interno"}))

if __name__ == "__main__": unittest.main()
